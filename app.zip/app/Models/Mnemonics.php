<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Mnemonics extends Model
{
    protected $guarded = [];
}
