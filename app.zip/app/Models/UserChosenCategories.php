<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserChosenCategories extends Model
{
    protected $guarded = [];
}
