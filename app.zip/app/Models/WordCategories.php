<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WordCategories extends Model
{
    protected $guarded = [];
}
