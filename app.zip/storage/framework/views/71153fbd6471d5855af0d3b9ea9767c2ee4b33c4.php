<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Word Master</title>

    <link rel="stylesheet" href="/bootstrap/bootstrap.min.css">
    <script src="/bootstrap/jquery-1.12.4.min.js"></script>
    <script src="/bootstrap/bootstrap.min.js"></script>

</head>
<body>

<div class="text-center">
    <h1>404</h1>
    <p class="text-center">Not Found</p>

    <br><br><br>
    <p>
        <a href="/">Go Home</a>
    </p>
</div>

</body>
</html>
<?php /**PATH F:\Development\Laravel\wm\resources\views/errors/404.blade.php ENDPATH**/ ?>