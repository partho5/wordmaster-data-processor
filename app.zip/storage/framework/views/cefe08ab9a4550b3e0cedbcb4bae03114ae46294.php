<?php echo e($slot); ?>

<?php /**PATH E:\Development\Laravel\wm\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>