<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>App User Log</title>





<!-- development time only -->
    <link rel="stylesheet" href="/bootstrap/bootstrap.min.css">
    <script src="/bootstrap/jquery-1.12.4.min.js"></script>
    <script src="/bootstrap/bootstrap.min.js"></script>


    <link href="https://fonts.googleapis.com/css?family=Nunito:300,600" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@500&display=swap" rel="stylesheet">

    <style>
        #container{
            padding: 8px;
        }
        .log:nth-child(2n+1){
            background-color: #dededebb;
        }
        .log:nth-child(2n){
            //background-color: #ccc;
        }
        .user{
            background: #00bd00;
            text-align: center;
        }
        .user .uid{
            color: #e5e05d;
        }
        .user .device-name{
            color: #f2f2f2;
            padding: 0 1em;
        }
        .user .os-v{
            color: #3511b8;
        }
        .diff{
            color: #047AB8;
        }
    </style>

</head>
<body>

<div id="container">
    <h2 class="text-center">App User Log</h2>
    <div>
        <?php $osV['21']='Lollipop 5.0'; $osV['22']='Lollipop 5.1'; $osV['23']='Marshmallow'; $osV['24']='Nougat 7.0'; $osV['25']='Nougat 7.1+'; $osV['26']='Oreo 8.0'; $osV['27']='Oreo 8.1';$osV['28']='Pie 9.0'; $osV['29']='Android 10'; $osV['30']='Android 11'; $osV['31']='Android 12'; $osV['32']='Android 12 L'; $osV['33']='Android 13' ?>

        <?php $__currentLoopData = $logData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userId=>$logs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xs-12 col-md-12 user">
                <span class="uid">user id : <?php echo e($userId); ?> </span>
                <span class="device-name"><?php echo e(@\App\Models\User::find($userId)->device_name); ?></span>
                <span class="os-v"><?php echo e(@$osV[\App\Models\User::find($userId)->os_version]); ?></span>
            </div>
            <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="log col-xs-12 col-md-12">
                        <div class="col-xs-6 col-md-2"><?php echo e($row['start']); ?></div>
                        <div class="col-xs-6 col-md-1 diff"><?php echo e($row['diff']); ?> sec</div>
                        <div class="col-xs-6 col-md-2 "><?php echo e($row['end']); ?></div>
                        <div class="col-xs-6 col-md-4"><?php echo e($row['activity']); ?>  <?php echo e($row['details']); ?></div>
                        <div class="col-xs-6 col-md-2"><?php echo e($row['wordIndex']); ?></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>


<script>
    $(document).ready(function () {

    });
</script>

</body>
</html>
<?php /**PATH E:\Development\Laravel\wm\resources\views/admin/log/app_user_activity.blade.php ENDPATH**/ ?>