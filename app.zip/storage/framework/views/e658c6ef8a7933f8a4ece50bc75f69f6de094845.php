

<?php $__env->startSection('title'); ?>
    <title>Affiliate Post Approval</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('external_resources'); ?>
    <link rel="stylesheet" href="/css/admin/affiliate_approval.css">

    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@300&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@300;400;500&display=swap" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body_container'); ?>
    <div class="col-md-12 text-center">
        <h2><span>Affiliate Post Approval</span></h2>


        <div style="background: rgba(220,218,75,0.2); border: 1px solid #dcdb89; ">
            <div>Gmail API: <b><?php echo e(LaravelGmail::user()); ?></b></div>
            <?php if(LaravelGmail::check()): ?>
                <a href="<?php echo e(url('oauth/gmail/logout')); ?>" class="">Logout</a>
            <?php else: ?>
                <a href="<?php echo e(url('oauth/gmail')); ?>">Login</a>
            <?php endif; ?>
        </div>


        <div class="col-md-12 col-xs-12 no-padding">
            <?php if(count($posts)>0): ?>
            <table class="table text-center">
                <tr>
                    <th class="text-center">Name</th>
                    <th class="text-center">Email</th>
                    <th class="text-center">Post Link</th>
                    <th class="text-center">Approval</th>
                </tr>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr postId="<?php echo e($post->postId); ?>" userid="<?php echo e($post->uid); ?>">
                        <td class="name"><?php echo e($post->name); ?></td>
                        <td class="email">
                            <div class="gen-info">
                                <span class="address"><?php echo e($post->email); ?></span>
                                <span class="request-time">requested at <span class="date-time"><?php echo e($post->created_at); ?></span></span>
                            </div>
                            <textarea class="50" rows="3"><?php echo e($emailMsg); ?></textarea>
                            <button class="btn btn-default send">
                                <img src="/images/icon/send_mail.png" class="icon send-mail-icon" alt="">
                                Send Mail & Approve
                            </button>
                        </td>
                        <td class="post-link">
                            <a href="<?php echo e($post->postLink); ?>" title="<?php echo e($post->postLink); ?>" target="_blank"><?php echo e(substr($post->postLink, 0, 20)); ?>....</a>
                        </td>
                        <td class="approval-status"></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <?php else: ?>
                <div>No affiliate posts to approve</div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {

            $('.email button').click(function(){
                const THIS = $(this);
                const postId = $(this).parents('tr').attr('postId');
                const userId = $(this).parents('tr').attr('userid');
                const email = $(this).parents('tr').find('.email').find('.address').text();
                const msg = $(this).parents('tr').find('.email').find('textarea').val();
                const userName = $(this).parents('tr').find('.name').text();

                if(postId && email){
                    $.ajax({
                        url : '/admin/tom/ajax/post/send_approval_mail',
                        type : 'post',
                        data : {
                            '_token' : "<?php echo e(csrf_token()); ?>",
                            userId : userId, postId : postId, email : email, userName : userName, msg : msg
                        }, success : function (response) {
                            console.log(response);
                            if(response === 'ok'){
                                THIS.parents('tr').find('.approval-status').text('Approved');
                                THIS.parents('tr').find('img.send-mail-icon').attr('src', '/images/icon/blue-tick.svg');
                            }
                        }, error : function (error) {
                            console.log("error :");
                            console.log(error);
                            //alert(error);
                        }
                    });
                }else{
                    alert("post id or email missing !");
                }
            });

        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Development\Laravel\wm\resources\views/admin/affiliate_approval.blade.php ENDPATH**/ ?>