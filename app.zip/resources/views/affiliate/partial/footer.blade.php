
<style>
    #footer{
        margin-top: 3em;
        //background-color: rgba(187, 194, 207, 0.3);
        font-size: 20px; /* not em. because this partial view used in different pages having different base font size em */
        margin-bottom: 2em;
    }
    hr {
        border: 0;
        clear:both;
        display:block;
        width: 100%;
        background-color: #919191;
        height: 1px;
    }
</style>


<div id="footer" class="col-md-12 col-xs-12">
    <hr>
    <div class="tos">
        <a href="/partner/terms-of-service" target="_blank">Terms of service</a>
    </div>
</div>