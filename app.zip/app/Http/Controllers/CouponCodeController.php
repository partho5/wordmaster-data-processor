<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CouponCodeController extends Controller
{
    //
}
