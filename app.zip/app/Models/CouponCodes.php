<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CouponCodes extends Model
{
    protected $guarded=[];
}
