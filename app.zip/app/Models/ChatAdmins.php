<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChatAdmins extends Model
{
    protected $guarded=[];
}
