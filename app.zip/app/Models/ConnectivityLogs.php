<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ConnectivityLogs extends Model
{
    protected $guarded = [];
}
