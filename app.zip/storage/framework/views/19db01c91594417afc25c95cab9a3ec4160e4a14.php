
<ul>
    policies:
</ul><?php /**PATH F:\Development\Laravel\wm\resources\views/affiliate/policies.blade.php ENDPATH**/ ?>