<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WordUsages extends Model
{
    protected $guarded = [];
}
