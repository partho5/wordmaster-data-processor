

<?php $__env->startSection('title'); ?>
    <title>Chat List</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('external_resources'); ?>
    <link rel="stylesheet" href="/css/admin/chat_list.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body_container'); ?>
    <div class="col-md-12 text-center">
        
        
            
            
        
        

        
            
                
                
            
        


        <?php $osV['21']='Lollipop 5.0'; $osV['22']='Lollipop 5.1'; $osV['23']='Marshmallow'; $osV['24']='Nougat 7.0'; $osV['25']='Nougat 7.1+'; $osV['26']='Oreo 8.0'; $osV['27']='Oreo 8.1';$osV['28']='Pie 9.0'; $osV['29']='Android 10'; $osV['30']='Android 11'; $osV['31']='Android 12'; $osV['32']='Android 12 L'; ?>

        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deviceId=>$device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-md-offset-3 col-xs-12 text-left device">
                <a class="device-id" href="/admin/tom/chat/user?device_id=<?php echo e($deviceId); ?>" target="_blank"> <?php echo e($deviceId); ?> </a>
                <?php $__currentLoopData = $device; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(! $info->seen_at): ?>
                        <!-- i.e. there's unseen msg -->
                        <span class="green-dot"></span>
                        <div> <?php echo e($info->device_name); ?> </div>
                        <?php break; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {

        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Development\Laravel\wm\resources\views/admin/chat_list.blade.php ENDPATH**/ ?>