<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PreviousJobExams extends Model
{
    protected $guarded = [];
}
