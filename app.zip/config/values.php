<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 3/9/2023
 * Time: 8:11 PM
 */

return [
    'adminEmail'    => env('ADMIN_EMAIL'),
    'affiliatePostApproveMailSubject' => "Your video / link has been reviewed",
    'affiliatePostApproveEmailTemplate' => "We saw that you created a nice video. Below we have provided you an affiliate link which you will put in the description of your video. When someone buys from your link, you will get the revenue share.",



    'referenceParamKey' => 'p' //or we can write 'ref' instead in future

];